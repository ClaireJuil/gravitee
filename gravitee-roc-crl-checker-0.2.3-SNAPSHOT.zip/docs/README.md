<!--

    (c) Copyright 2023-2024, ANS. All rights reserved.

-->
# ROC CRL Checker  
 Contrôle la non révocation du certificat client d'une requête mTLS entrante

## Phase

* onRequest

## Description

Le plugin contrôle la non révocation du certificat client (mTLS) et selon la profondeur choisie de sa première ou de ses 2 premières autorités de confiance. 

Le plugin est prévu pour être utilisé après le plugin natif 'SSL enforcement' qui vérifie la présence et la validité du certificat client.  
Il s'appuie sur une Resource de type 'CRL Download Resource' qui construit quotidiennement un bundle de CRL pour les autorités de certification configurées dans la ressource.

## Configuration

*   Nom de la ressource avec le bundle des CRL.<br> Nom donné à la ressource de type 'CRL Download Resource' qui construit le bundle de CRL.<br> Dans la configuration de la ressource il faut renseigner une liste d'url de téléchargement de CRL et de la clé publique au format PEM de l'autorité émettrice de la CRL.<br>  **NB**: si le contrôle de la non-révocation d'un certificat (que ce soit pour un certificat de feuille ou si demandé pour une autorité ) ne peut pas être effectué parce que le bundle de CRL ne contient pas les CRL de l'autorité supérieure, la requête sera renvoyée avec le statut 401 (Non autorisé).

*   Profondeur de contrôle.<br> Nombre de certificats pour lesquels la non-révocation est vérifiée : 1 pour le certificat de feuille, 3 pour les certificats de feuille et les deux premières autorités.<br>
**NB** : si la requête entrante ne contient pas le certificat de la ou les autorités de confiance nécessaire à une profondeur de vérification de 2 ou 3, seul le ou les certificats fournis seront vérifiés. Si le dernier certificat de la requête (feuille ou autorité) est non revoqué, la stratégie sera passante (passage à la stratégie suivante).<br>
