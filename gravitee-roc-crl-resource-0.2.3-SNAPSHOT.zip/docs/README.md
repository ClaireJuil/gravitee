<!--

    (c) Copyright 2023-2024, ANS. All rights reserved.

-->
# ROC CRL Resource

## Description

Cette ressource est un objet X509CR contenant la liste des CRLs téléchargées quotidiennement

## Configuration


