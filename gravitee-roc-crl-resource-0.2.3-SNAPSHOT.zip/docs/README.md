<!--

    (c) Copyright 2023-2024, ANS. All rights reserved.

-->
# CRL Download Resource

## Description

Cette ressource construit quotidiennement un bundle de CRL pour les autorités de certification configurées dans la ressource.
Ce bundle est nécessaire au plugin 'ROC CRL Checker' qui vérifie la non révocation d'un certificat client (mTLS).

## Configuration

Liste d'URL de téléchargement de CRL et du certificat (clé publique) de l'autorité de certification émettrice de la CRL.<br><br>
Pour chaque item de la liste:<br>

*   Url de téléchargement des CRL <br> exemple: http://igc-sante.esante.gouv.fr/CRL/ACI-EL-ORG-TEST.crl

*   Certificat (clé publique) de l'autorité de certification au format PEM qui fournit les CRL. <br> Ce certificat est utilisé pour vérifier la signature de la CRL téléchargée.

**NB** :<br>
* le bundle est reconstruit quotidiennement.
* une crl n'est ajoutée au bundle que si sa signature est valide.
* une crl n'est ajoutée au bundle qu'après vérification de sa non-expiration.


