<!--

    (c) Copyright 2023-2024, ANS. All rights reserved.

-->
# ROC Proxy configuration source

## Description

Cette ressource définit l'accès à la configuration du proxy RPN hébergée par
l'application de gestion.

## Configuration

Définir l'URL , de l'application de gestion.
